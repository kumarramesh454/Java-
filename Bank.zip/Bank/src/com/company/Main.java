package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Cash  cash_payment=new Cash();
        Paypal PayPal_payment=new Paypal();
        BankCard bankcard_payment=new BankCard();

    DoPayment(cash_payment);
    DoPayment(PayPal_payment);
    DoPayment(bankcard_payment);
    }
    public static void DoPayment(Payment p)
    {
        p.pay();
    }
}
