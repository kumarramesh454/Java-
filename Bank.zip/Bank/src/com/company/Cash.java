package com.company;

public class Cash implements Payment{
    public void pay(){
        System.out.println("Cash payment");
    }
}
