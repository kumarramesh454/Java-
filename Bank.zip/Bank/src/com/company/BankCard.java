package com.company;

public class BankCard implements Payment{
    public void pay(){
        System.out.println("Bank card payment");
    }
}
