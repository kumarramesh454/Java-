package com.company;

public interface Payment {
    public void pay();
}
