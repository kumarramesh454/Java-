package com.company;

public class Paypal implements Payment {
    public void pay(){
        System.out.println("PayPal payment");
    }
}
